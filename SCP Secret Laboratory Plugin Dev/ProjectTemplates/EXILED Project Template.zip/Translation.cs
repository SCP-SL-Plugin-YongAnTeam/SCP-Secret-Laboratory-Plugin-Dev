﻿using Exiled.API.Interfaces;

namespace $safeprojectname$
{
    /// <summary>
    /// 插件的翻译
    /// </summary>
    public sealed class Translation : ITranslation
    {

    }
}
